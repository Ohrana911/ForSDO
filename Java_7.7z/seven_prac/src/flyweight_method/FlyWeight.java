package flyweight_method;

import java.util.HashMap;
import java.util.Map;

public class FlyWeight {
    public static void main(String[] args) {
        FlyWeightChoice flyWeightChoice = new FlyWeightChoice();
        Car car1 = flyWeightChoice.getCar("red");
        Car car2 = flyWeightChoice.getCar("red");
        System.out.println(car1.equals(car2));
        System.out.println(car1.color);
    }
}

class Car{
    String color;
}

class FlyWeightChoice{
    Map<String, Car> map = new HashMap<>();
    Car getCar(String color){
        Car car = map.get(color);
        if (car == null){
            car = new Car();
            car.color = color;
            map.put(color, car);
        }
        return car;
    }
}