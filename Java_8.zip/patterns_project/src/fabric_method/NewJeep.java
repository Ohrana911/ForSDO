package fabric_method;

public class NewJeep extends Jeep{
    public void Develop(){
        System.out.println("Development is comming soon... " + "\n" +
                "We are adding new functions on our jeep or we " + "\n" +
                "can ovveride some jeep's features");
    }
}
