package fabric_method;

public class Jeep implements Car {


    @Override
    public void drive() {
        System.out.println("Speed is 60 km/h!");
    }

    @Override
    public void stop() {
        System.out.println("Braking distance is 20 meters");
    }

    @Override
    public void Develop() {

    }


}
