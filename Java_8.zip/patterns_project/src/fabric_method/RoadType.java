package fabric_method;

public enum RoadType {
    CITY,
    COUNTRY_SIDE,
    WATER_AREA
}
