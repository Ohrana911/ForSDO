package fabric_method;

public class Test {

    public static void main(String[] args) {

        System.out.println("------- НЕ ФАБРИЧНЫЙ МЕТОД -------"+ "\n");
        System.out.println("\n" + "- создание джипа -"+ "\n");

        // реализация фабрики без фабричного метода

        Car jeep = new Jeep();
        jeep.drive();
        jeep.stop();

        System.out.println("\n" + "- создание спорт авто -"+ "\n");

        Car sportcar = new SportCar();
        sportcar.drive();

        System.out.println("\n\n" + "------- ФАБРИЧНЫЙ МЕТОД -------"+ "\n");

        // реализация фабрики с фабричным методом getCar
        System.out.println("\n" + "- создание спорт авто -"+ "\n");
        CarSelector carSelector = new CarSelector();

        Car car = carSelector.getCar(RoadType.CITY);
        car.drive();

        System.out.println("\n" + "- создание нового джипа -"+ "\n");

        car = carSelector.getCar(RoadType.WATER_AREA);
        car.drive();
        System.out.println("\n");
        car.Develop();

        System.out.println("\n" + "- создание джипа -"+ "\n");

        car = carSelector.getCar(RoadType.COUNTRY_SIDE);
        car.drive();
    }
}
