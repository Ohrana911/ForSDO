package fabric_method;

// сама фабрика по созданию автомобилей,
// т.е. смысл в том что создание новых объектов
// ( машин намного упрощается )

public class CarSelector{

    // фабричный метод который создает нужный автомобиль
    public Car getCar(RoadType roadType){
        Car car = null;
        switch (roadType){ // если входящий параметр такой то такой то,
            // то создаем нужный нам объект и возвращаем его
            case CITY:
                car = new SportCar();
                break;
            case COUNTRY_SIDE:
                car = new Jeep();
                break;
            case WATER_AREA:
                car = new NewJeep();
                break;
        }

        return car;
    }
}
