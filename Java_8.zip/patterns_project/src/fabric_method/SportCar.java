package fabric_method;

public class SportCar implements Car {

    @Override
    public void drive() {
        System.out.println("YO BRO WTF U DOIN" +
                " UR SPEED LIMITER REACHED THE END OF MEANINGS:" +
                " Speed is 360 km/h");
    }

    @Override
    public void stop() {
        System.out.println("mf stopped in 0.0000032 miliseconds");
    }

    @Override
    public void Develop() {

    }
}
