package builder_method;

public class Main {
    public static void main(String[] args) {
        CarBuilder car = new CarBuilderIMpl().setName("ВАЗ-2107").setRelease_date(2007).setCost(40000);
        car.print();
    }
}

class Car {
    String name;
    int release_date;
    double cost;

}

interface  CarBuilder{
    CarBuilder setName(String name);
    CarBuilder setRelease_date(int release_date);
    CarBuilder setCost(double cost);
    Car build();
    void print();
}

class CarBuilderIMpl implements CarBuilder{
    Car car = new Car();

    @Override
    public CarBuilder setName(String name) {
        car.name = name;
        return this;
    }

    @Override
    public CarBuilder setRelease_date(int release_date) {
        car.release_date = release_date;
        return this;
    }

    @Override
    public CarBuilder setCost(double cost) {
        car.cost = cost;
        return this;
    }

    @Override
    public Car build() {
        return car;
    }

    @Override
    public void print() {
        System.out.println(car.name + " " + car.release_date + " " + car.cost);
    }
}