package prototype_method;

public class Prototype {
    public static void main(String[] args) throws CloneNotSupportedException {
        Cash cash = new Cash();
        cash.setCar(new Car());

        Car car = cash.getCar();
    }
}

class Car implements Cloneable{
    public Car clone() throws CloneNotSupportedException {
        return (Car)super.clone();
    }
}

class Cash{
    private Car car;

    public Car getCar() throws CloneNotSupportedException {
        return car.clone();
    }

    public void setCar(Car car) {
        this.car = car;
    }

}