package abstract_factrory_method;

public class RussianFactory implements TransportFactory {
    @Override
    public Car createCar() {
        return new LadaCar();
    }

    @Override
    public Aircraft createPlane() {
        return new RusPlane();
    }
}
