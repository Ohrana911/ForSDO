package abstract_factrory_method;

public class ChineaseFactory implements TransportFactory{
    @Override
    public Car createCar() {
        return new ChingChongCar();
    }

    @Override
    public Aircraft createPlane() {
        return new SuperIdolPlane();
    }
}
