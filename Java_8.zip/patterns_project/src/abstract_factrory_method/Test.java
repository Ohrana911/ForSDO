package abstract_factrory_method;
import java.util.Scanner;
// шаблон абстрактная фабрика используется тогда когда нужно создать целые семейства каких то объектов а эти семейства разные

public class Test {

    private static TransportFactory factory;

    public static void main(String[] args) {

        System.out.println("Да или нет?\n");

        Scanner scanner = new Scanner(System.in);

        boolean flag = scanner.nextBoolean();

        if (flag) {
            factory = new RussianFactory();
        }else{
            factory = new ChineaseFactory();
        }

        factory.createCar();
        factory.createPlane();


        TransportFactory russianFactory = new RussianFactory();

        Car car = russianFactory.createCar();

        car.drive();
    }
}
