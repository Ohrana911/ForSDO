package abstract_factrory_method;

public class RusPlane implements Aircraft{
    @Override
    public void flight() {
        System.out.println("Русский боинг готов! \n");
    }
}
