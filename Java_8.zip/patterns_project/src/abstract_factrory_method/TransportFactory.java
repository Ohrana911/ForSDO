package abstract_factrory_method;

public interface TransportFactory {
    // наша фабрика которая будет создавать транспортные средства
    // (создание абстрактной фабрики, от которой будет реализоваться конкретная фабрика)

    Car createCar(); // автомобили

    Aircraft createPlane(); // самолеты

}
