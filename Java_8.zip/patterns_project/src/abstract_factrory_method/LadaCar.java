package abstract_factrory_method;

public class LadaCar implements Car {
    @Override
    public void drive() {
        System.out.println("ВАЗ_21911 начал движение..." + "\n");
    }

    @Override
    public void stop() {
        System.out.println("Передовые технологии невозможно остановить." + "\n");
    }

    @Override
    public void Develop() {
        System.out.println("В процессе.." + "\n");
    }
}
