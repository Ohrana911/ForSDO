package abstract_factrory_method;

public interface Aircraft {

    void flight();
}
