package abstract_factrory_method;

public interface Car {

    void drive();

    void stop();

    void Develop();
}