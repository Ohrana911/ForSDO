package abstract_factrory_method;

public class ChingChongCar implements Car{
    @Override
    public void drive() {
        System.out.println("ok\n +10 social credits");
    }

    @Override
    public void stop() {
        System.out.println("ok\n -99999 social credits");
    }

    @Override
    public void Develop() {
        System.out.println("ok\n +1000 social credits");
    }
}
