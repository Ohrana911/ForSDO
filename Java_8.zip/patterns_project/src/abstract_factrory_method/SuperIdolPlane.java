package abstract_factrory_method;

public class SuperIdolPlane implements Aircraft {
    @Override
    public void flight() {
        System.out.println("$made in china$ \n");
    }
}
